// Signal & Structure: editorial portfolio page with asymmetric composition, ink/cobalt palette, and centralized content data.
import { useState } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  Check,
  ChevronRight,
  Download,
  ExternalLink,
  Github,
  Linkedin,
  Mail,
  Menu,
  X,
} from "lucide-react";

const content = {
  person: {
    name: "Alex Morgan",
    role: "Product designer & front-end developer",
    location: "Based in Copenhagen · Working globally",
    email: "hello@alexmorgan.design",
    intro:
      "I turn complex product problems into calm, usable interfaces — from the first messy question to the final polished interaction.",
    availability: "Available for select projects · 2025",
  },
  about: {
    eyebrow: "A little context",
    title: "Good work starts with better questions.",
    body: "I’m a product designer and developer with 7+ years of experience shaping digital products for teams that care about the details. My practice sits between strategy, interface design, and the code that makes ideas real.",
    note: "Currently exploring systems that make public services feel more human.",
  },
  skills: [
    { label: "Product strategy", detail: "Framing · research · roadmaps" },
    { label: "Interface design", detail: "Flows · systems · prototyping" },
    { label: "Front-end craft", detail: "React · TypeScript · motion" },
    { label: "Team practice", detail: "Workshops · critique · mentoring" },
  ],
  projects: [
    {
      number: "01",
      title: "Civic / service clarity",
      category: "Product design · 2024",
      description: "A calmer way to navigate essential city services, built around plain language and visible progress.",
      image: "/manus-storage/project-civic_12c5953d.jpg",
      tags: ["Strategy", "UX / UI", "Prototyping"],
    },
    {
      number: "02",
      title: "Fieldnotes / find the thread",
      category: "Design system · 2023",
      description: "An editorial research archive that helps teams move from scattered notes to shared understanding.",
      image: "/manus-storage/project-fieldnotes_29b36329.jpg",
      tags: ["Systems", "Interaction", "Front-end"],
    },
  ],
  experience: [
    { year: "2022—Now", role: "Independent designer / developer", company: "Self-directed studio", detail: "Working with mission-led teams on products, systems, and the spaces between them." },
    { year: "2019—22", role: "Senior product designer", company: "Northstar Labs", detail: "Led product design across a distributed team building tools for public-sector operators." },
    { year: "2017—19", role: "Designer & developer", company: "Studio Current", detail: "Designed and shipped digital identities, websites, and prototypes for cultural organisations." },
  ],
};

const navItems = ["about", "skills", "projects", "experience", "contact"];

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setMenuOpen(false);
  };

  return (
    <div className="site-shell">
      <aside className="index-rail" aria-label="Section index"><span className="rail-word">AM / INDEX</span><span className="rail-track" /><span>00</span><span>01</span><span>02</span><span>03</span><span>04</span><span>05</span></aside>
      <header className="site-header">
        <a className="brand" href="#home" aria-label="Alex Morgan home" onClick={() => scrollTo("home")}>
          <span className="brand-mark" aria-hidden="true"><span /><span /></span>
          <span className="brand-name">ALEX<span> / M.</span></span>
        </a>
        <nav className={`desktop-nav ${menuOpen ? "mobile-nav-open" : ""}`} aria-label="Primary navigation">
          {navItems.map((item, index) => (
            <button key={item} onClick={() => scrollTo(item)}>
              <span className="nav-index">0{index + 1}</span>{item}
            </button>
          ))}
          <a className="header-cta" href={`mailto:${content.person.email}`}><Mail size={15} /> Let’s talk</a>
        </nav>
        <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? "Close navigation" : "Open navigation"} aria-expanded={menuOpen}>
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </header>

      <main>
        <section id="home" className="hero-section section-pad">
          <div className="hero-index">00 <span>INTRO</span></div>
          <div className="hero-copy">
            <p className="eyebrow">{content.person.availability}</p>
            <h1>Designing<br /><em>with intent.</em></h1>
            <p className="hero-intro">{content.person.intro}</p>
            <div className="hero-actions">
              <button className="button button-primary" onClick={() => scrollTo("projects")}>View selected work <ArrowDownRight size={17} /></button>
              <a className="text-link" href="/alex-morgan-resume.pdf" download><Download size={15} /> Download résumé</a>
            </div>
          </div>
          <div className="hero-art-wrap">
            <div className="hero-art-label">Portfolio / 2025 <span>↘</span></div>
            <img className="hero-art" src="/manus-storage/portfolio-hero_f853b7bb.jpg" alt="Abstract cobalt geometric artwork on an ivory paper background" />
            <div className="hero-caption"><span>01</span><span>Make the complex feel clear.</span></div>
          </div>
          <div className="scroll-cue"><span className="scroll-line" /> Scroll to explore</div>
        </section>

        <section id="about" className="section-pad about-section">
          <SectionMarker number="01" label={content.about.eyebrow} />
          <div className="about-grid">
            <h2>{content.about.title}</h2>
            <div className="about-copy">
              <p className="lead-copy">{content.about.body}</p>
              <div className="about-note"><span className="note-mark">+</span><span>{content.about.note}</span></div>
              <a className="text-link cobalt-link" href={`mailto:${content.person.email}`}>More about the practice <ArrowUpRight size={15} /></a>
            </div>
          </div>
        </section>

        <section id="skills" className="section-pad skills-section">
          <SectionMarker number="02" label="What I bring" />
          <div className="skills-heading-row"><h2>Small details.<br /><em>Big difference.</em></h2><p>From early discovery to final implementation, I bring a systems view and a hands-on approach to every stage.</p></div>
          <div className="skills-list">
            {content.skills.map((skill, index) => <div className="skill-row" key={skill.label}><span className="skill-number">0{index + 1}</span><h3>{skill.label}</h3><span className="skill-detail">{skill.detail}</span><ChevronRight className="skill-arrow" size={20} /></div>)}
          </div>
        </section>

        <section id="projects" className="section-pad projects-section">
          <SectionMarker number="03" label="Selected work" />
          <div className="projects-heading"><div><span className="display-kicker">CASE NOTES / 2023—24</span><h2>A few things<br /><em>in the world.</em></h2></div><span className="project-count">02 / 04</span></div>
          <div className="projects-list">
            {content.projects.map((project) => <article className="project-card" key={project.number}><div className="project-visual"><img src={project.image} alt="" /><span className="project-number">{project.number}</span><span className="project-open"><ArrowUpRight size={18} /></span></div><div className="project-meta"><p className="eyebrow">{project.category}</p><h3>{project.title}</h3><p>{project.description}</p><div className="tag-list">{project.tags.map(tag => <span key={tag}>{tag}</span>)}</div></div></article>)}
          </div>
          <a className="all-work-link" href="#contact" onClick={(e) => { e.preventDefault(); scrollTo("contact"); }}>Discuss a project <ArrowUpRight size={17} /></a>
        </section>

        <section id="experience" className="section-pad experience-section">
          <SectionMarker number="04" label="The short version" />
          <div className="experience-grid"><div><span className="display-kicker display-kicker-light">A WORKING HISTORY</span><h2>Where I’ve<br /><em>been useful.</em></h2></div><div className="experience-list">{content.experience.map((item) => <div className="experience-row" key={item.year}><span className="experience-year">{item.year}</span><div><h3>{item.role}</h3><p className="company">{item.company}</p><p className="experience-detail">{item.detail}</p></div></div>)}</div></div>
        </section>

        <section id="contact" className="contact-section section-pad">
          <div className="contact-index">05 <span>CONTACT</span></div>
          <div className="contact-grid"><div><p className="eyebrow">Have a good question?</p><h2>Let’s make<br /><em>something useful.</em></h2></div><div className="contact-side"><p>Tell me what you’re working on, what feels stuck, or what you’re curious about. I’ll get back to you within a few days.</p><a className="contact-email" href={`mailto:${content.person.email}`}>{content.person.email} <ArrowUpRight size={21} /></a><div className="contact-links"><a href="#contact"><Linkedin size={16} /> LinkedIn</a><a href="#contact"><Github size={16} /> GitHub</a></div></div></div>
        </section>
      </main>

      <footer className="site-footer"><span>© 2025 {content.person.name}</span><span>{content.person.location}</span><a href="#home" onClick={(e) => { e.preventDefault(); scrollTo("home"); }}>Back to top ↑</a></footer>
    </div>
  );
}

function SectionMarker({ number, label }: { number: string; label: string }) {
  return <div className="section-marker"><span className="marker-number">{number}</span><span className="marker-line" /><span className="marker-label">{label}</span></div>;
}
